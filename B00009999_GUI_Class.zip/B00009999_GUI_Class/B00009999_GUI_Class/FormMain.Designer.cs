﻿namespace B00009999_GUI_Class
{
    partial class FormMain
    {
        /// <summary>
        /// 設計工具所需的變數。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 清除任何使用中的資源。
        /// </summary>
        /// <param name="disposing">如果應該處置受控資源則為 true，否則為 false。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form 設計工具產生的程式碼

        /// <summary>
        /// 此為設計工具支援所需的方法 - 請勿使用程式碼編輯器修改
        /// 這個方法的內容。
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.btnButton = new System.Windows.Forms.Button();
            this.btnBMI = new System.Windows.Forms.Button();
            this.btnTextBox = new System.Windows.Forms.Button();
            this.button1 = new System.Windows.Forms.Button();
            this.button_TryCatch = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this.btnGameFinalPaws = new System.Windows.Forms.Button();
            this.button3 = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.Color.Honeydew;
            this.label1.Font = new System.Drawing.Font("標楷體", 21.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label1.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.label1.Location = new System.Drawing.Point(58, 9);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(193, 29);
            this.label1.TabIndex = 3;
            this.label1.Text = "多媒體系乙班";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.BackColor = System.Drawing.Color.Honeydew;
            this.label3.Font = new System.Drawing.Font("標楷體", 21.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label3.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.label3.Location = new System.Drawing.Point(311, 9);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(148, 29);
            this.label3.TabIndex = 6;
            this.label3.Text = "B04111222";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.BackColor = System.Drawing.Color.Honeydew;
            this.label4.Font = new System.Drawing.Font("標楷體", 21.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label4.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.label4.Location = new System.Drawing.Point(500, 9);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(103, 29);
            this.label4.TabIndex = 7;
            this.label4.Text = "小叮噹";
            // 
            // btnButton
            // 
            this.btnButton.Location = new System.Drawing.Point(48, 156);
            this.btnButton.Name = "btnButton";
            this.btnButton.Size = new System.Drawing.Size(142, 59);
            this.btnButton.TabIndex = 8;
            this.btnButton.Text = "按鈕";
            this.btnButton.UseVisualStyleBackColor = true;
            this.btnButton.Click += new System.EventHandler(this.btnButton_Click);
            // 
            // btnBMI
            // 
            this.btnBMI.Location = new System.Drawing.Point(48, 231);
            this.btnBMI.Name = "btnBMI";
            this.btnBMI.Size = new System.Drawing.Size(142, 79);
            this.btnBMI.TabIndex = 9;
            this.btnBMI.Text = "BMI計算";
            this.btnBMI.UseVisualStyleBackColor = true;
            // 
            // btnTextBox
            // 
            this.btnTextBox.Location = new System.Drawing.Point(210, 156);
            this.btnTextBox.Name = "btnTextBox";
            this.btnTextBox.Size = new System.Drawing.Size(142, 59);
            this.btnTextBox.TabIndex = 10;
            this.btnTextBox.Text = "輸入框";
            this.btnTextBox.UseVisualStyleBackColor = true;
            this.btnTextBox.Click += new System.EventHandler(this.btnTextBox_Click);
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(210, 241);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(142, 59);
            this.button1.TabIndex = 11;
            this.button1.Text = "期中考-攝氏轉華氏";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // button_TryCatch
            // 
            this.button_TryCatch.Location = new System.Drawing.Point(367, 156);
            this.button_TryCatch.Name = "button_TryCatch";
            this.button_TryCatch.Size = new System.Drawing.Size(142, 59);
            this.button_TryCatch.TabIndex = 12;
            this.button_TryCatch.Text = "TryCatch";
            this.button_TryCatch.UseVisualStyleBackColor = true;
            this.button_TryCatch.Click += new System.EventHandler(this.button_TryCatch_Click);
            // 
            // button2
            // 
            this.button2.Location = new System.Drawing.Point(367, 241);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(142, 59);
            this.button2.TabIndex = 13;
            this.button2.Text = "Timer";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // btnGameFinalPaws
            // 
            this.btnGameFinalPaws.Location = new System.Drawing.Point(515, 156);
            this.btnGameFinalPaws.Name = "btnGameFinalPaws";
            this.btnGameFinalPaws.Size = new System.Drawing.Size(142, 59);
            this.btnGameFinalPaws.TabIndex = 14;
            this.btnGameFinalPaws.Text = "終極密碼";
            this.btnGameFinalPaws.UseVisualStyleBackColor = true;
            this.btnGameFinalPaws.Click += new System.EventHandler(this.btnGameFinalPaws_Click);
            // 
            // button3
            // 
            this.button3.Location = new System.Drawing.Point(515, 241);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(142, 59);
            this.button3.TabIndex = 15;
            this.button3.Text = "CheckBOx";
            this.button3.UseVisualStyleBackColor = true;
            this.button3.Click += new System.EventHandler(this.button3_Click);
            // 
            // FormMain
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.button3);
            this.Controls.Add(this.btnGameFinalPaws);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.button_TryCatch);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.btnTextBox);
            this.Controls.Add(this.btnBMI);
            this.Controls.Add(this.btnButton);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label1);
            this.Name = "FormMain";
            this.Text = "GUI 主程式";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Button btnButton;
        private System.Windows.Forms.Button btnBMI;
        private System.Windows.Forms.Button btnTextBox;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button button_TryCatch;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Button btnGameFinalPaws;
        private System.Windows.Forms.Button button3;
    }
}

